# asyncServo
An async servo library for Arduino

Allows for smoothing of servo motion without blocking.
Also allows for a number of servo steps that you can play through.
